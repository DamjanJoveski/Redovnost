package com.example.redovnost;

public class Vraboten {

    public String ime;
    public String prezime;
    public int saati;

    public boolean active;



    public Vraboten(String ime, String prezime, int saati, boolean active) {
        this.ime = ime;
        this.prezime = prezime;
        this.saati = saati;
        this.active = active;

    }
}
