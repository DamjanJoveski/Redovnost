package com.example.redovnost;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

import static com.example.redovnost.Writer.*;

public class Redovnost extends Application {

    Vraboten damjan = new Vraboten("Дамјан","Јовески",0,false);
    Vraboten lili = new Vraboten("Лилиен","Домазетоски",0,false);
    Vraboten simona = new Vraboten("Симона","Димоски",0,false);
    Vraboten kamelija = new Vraboten("Камелија","Србиновска",0,false);

    ArrayList<Vraboten> list = new ArrayList<Vraboten>();
    boolean smena = true;
    boolean otvoreno=false;


    @Override
    public void start(Stage stage) throws IOException {

        list.add(damjan);
        list.add(lili);
        list.add(kamelija);
        list.add(simona);

        Label info = new Label();



        BorderPane root = new BorderPane();
        root.setPadding(new Insets(15));

        stage.setTitle("Redovnost");


        Label title = new Label("Schatze Битола 2");
        title.setStyle("-fx-text-fill:#fffffe ");
        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER);
        hbox.getChildren().add(title);
        root.setTop(hbox);
        root.setStyle("-fx-background-color: #16161a");


        ToggleButton vraboten1 = new ToggleButton(damjan.ime);
        vraboten1.setOnAction(e -> {damjan.active=true;otvoreno=true;});
        vraboten1.setStyle("-fx-background-color:#7f5af0;");
        vraboten1.setTextFill(Paint.valueOf("#fffffe"));


        ToggleButton vraboten2 = new ToggleButton(lili.ime);
        vraboten2.setOnAction(e->{lili.active=true;otvoreno=true;});
        vraboten2.setStyle("-fx-background-color:#7f5af0;");
        vraboten2.setTextFill(Paint.valueOf("#fffffe"));

        ToggleButton vraboten3 = new ToggleButton(simona.ime);
        vraboten3.setOnAction(e->{simona.active=true;otvoreno=true;});
        vraboten3.setStyle("-fx-background-color:#7f5af0;");
        vraboten3.setTextFill(Paint.valueOf("#fffffe"));

        ToggleButton vraboten4 = new ToggleButton(kamelija.ime);
        vraboten4.setOnAction(e->{kamelija.active=true;otvoreno=true;});
        vraboten4.setStyle("-fx-background-color:#7f5af0;");
        vraboten4.setTextFill(Paint.valueOf("#fffffe"));




        VBox vraboteni = new VBox();
        vraboteni.setAlignment(Pos.CENTER_LEFT);
        vraboteni.setSpacing(50);
        vraboteni.getChildren().addAll(vraboten1,vraboten2,vraboten3,vraboten4);
        root.setLeft(vraboteni);


        Button prva = new Button("Прва Смена");
        prva.setOnAction(e -> {
            try {
                writerPrva();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
        prva.setStyle("-fx-background-color:#7f5af0;");
        prva.setTextFill(Paint.valueOf("#fffffe"));

        Button vtora = new Button("Втора Смена");
        prva.setOnAction(e -> {
            try {
                writerPrva();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
        vtora.setStyle("-fx-background-color:#7f5af0;");
        vtora.setTextFill(Paint.valueOf("#fffffe"));

        Button finish = new Button("Затвори");
        finish.setOnAction(e -> {
            try {
                writer.close();
                stage.close();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
        finish.setStyle("-fx-background-color:#7f5af0;");
        finish.setTextFill(Paint.valueOf("#fffffe"));






        HBox centar = new HBox();
        centar.setAlignment(Pos.CENTER);
        centar.setSpacing(60);
        centar.getChildren().addAll(prva,vtora,finish);
        root.setCenter(centar);




        Scene scene = new Scene(root, 500, 400);
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}